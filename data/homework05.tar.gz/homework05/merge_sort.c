#include "list.h"
#include <string.h>

#define LINE_SIZE 1024

int main() {
    char line[1024];
    while (fgets(line, LINE_SIZE, stdin)) {
        // Parse the line and append each data element to the tail of a linked list
        // using list_append_tail

        // Use list_merge_sort to sort the data

        // Print the sorted data using list_print
    }
}