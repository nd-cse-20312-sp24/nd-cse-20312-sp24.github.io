#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "string_methods.h"

#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
    char buffer[BUF_SIZE];

    // TODO: Get the first line of input from stdin,
    // remove the final newline if necessary, and split
    // it into a string array, with ',' as the delimeter
    
    // TODO: Get the second line of input from stdin,
    // remove the final newline if necessary, and split
    // it into a string array, with ',' as the delimeter

    // TODO: Find the duplicate values and print them
    // to stdout

    // TODO: Free anything that you allocated from the heap

    return 0;
}