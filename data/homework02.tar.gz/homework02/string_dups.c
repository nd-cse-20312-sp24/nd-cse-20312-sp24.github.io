#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "string_methods.h"

#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
    char buffer[BUF_SIZE];

    fgets(buffer, BUF_SIZE, stdin);
    string_chomp(buffer);
    char **class1 = string_split(buffer, ',');
    
    fgets(buffer, 1024, stdin);
    string_chomp(buffer);
    char **class2 = string_split(buffer, ',');

    char **dups = string_find_dups(class1, class2);
    for (int i = 0; dups[i]; i++) {
        puts(dups[i]);
    }

    string_array_free(dups);
    string_array_free(class1);
    string_array_free(class2);

    return 0;
}