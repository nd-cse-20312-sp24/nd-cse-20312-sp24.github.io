#pragma once

#include <stdlib.h>
#include <stdbool.h>

// int string_count_dups(char **class1, char **class2);
char **string_find_dups(char **class1, char **class2);
size_t	string_array_size(char **sv);
bool string_array_contains(char **sv, char *s);
void string_chomp(char *s);
size_t string_array_size(char **sv);
char **string_split(char *s, char delim);
void string_array_free(char **sv);
