#!/bin/bash

# Configuration

PROGRAM=freq
EXECUTABLE=./$PROGRAM
WORKSPACE=/tmp/$PROGRAM.$(id -u)
POINTS=2
FAILURES=0

export LC_ALL=C

# Functions

error() {
    echo "$@"
    [ -r $WORKSPACE/test ] && cat $WORKSPACE/test
    echo
    FAILURES=$((FAILURES + 1))
}

cleanup() {
    STATUS=${1:-$FAILURES}
    rm -fr $WORKSPACE
    exit $STATUS
}

input0() {
    cat <<EOF
Rage is a force sometimes
That we all
That we all go crying back to misinformed
But it pays us all to forgive
Know that I will always be here
For you even
When I'm gone (Gone from this world)
From this world (Deep waters)
Deep the waters of the well
What do you really want?
What do you really need?
What do you really want from me?
The swan softly sleeps
She calls reflections down beyond
The willow tree
Do you miss me?
Though I'm often gone
Know that I will always be here
For you even
When you've gone (Gonе from this world)
From this world (Deep waters)
Deep the waters of thе well
What do you really want?
What do you really need?
What do you really want from me?
What do you really need?
The pines of the morning star
They call reflections down beyond
The broken hearts
Do you miss me now I've gone?
Know that I will always be there for you
Even though I had to let you go
What do you really want?
What do you really need?
EOF
}

output0() {
    cat <<EOF
1	a
1	back
1	broken
1	but
1	call
1	calls
1	crying
1	force
1	forgive
1	gon
1	had
1	hearts
1	i've
1	is
1	it
1	let
1	misinformed
1	morning
1	now
1	often
1	pays
1	pines
1	rage
1	she
1	sleeps
1	softly
1	sometimes
1	star
1	swan
1	th
1	there
1	they
1	tree
1	us
1	willow
1	you've
2	beyond
2	down
2	go
2	here
2	i'm
2	miss
2	reflections
2	though
2	we
2	well
2	when
3	all
3	always
3	be
3	even
3	for
3	know
3	of
3	to
3	will
4	deep
4	i
4	me
4	need
4	this
4	waters
4	world
5	gone
5	that
5	want
6	from
8	the
9	really
9	what
11	do
15	you
EOF
}

input1() {
    cat <<EOF
Hate to give the satisfaction asking how you're doing now
How's the castle built off people you pretend to care about?
Just what you wanted
Look at you, cool guy, you got it
I see the parties and the diamonds sometimes when I close my eyes
Six months of torture you sold as some forbidden paradise
I loved you truly
You gotta laugh at the stupidity
'Cause I've made some real big mistakes
But you make the worst one look fine
I should've known it was strange
You only come out at night
I used to think I was smart
But you made me look so naive
The way you sold me for parts
As you sunk your teeth into me, oh
Bloodsucker, fame fucker
Bleedin' me dry like a goddamn vampire
And every girl I ever talked to told me you were bad, bad news
You called them crazy, God, I hate the way I called 'em crazy too
You're so convincing
How do you lie without flinching?
(How do you lie? How do you lie? How do you lie?)
Oh, what a mesmerizing, paralyzing, fucked up little thrill
Can't figure out just how you do it and God knows I never will
Went for me and not her
'Cause girls your age know better
I've made some real big mistakes
But you make the worst one look fine
I should've known it was strange
You only come out at night
I used to think I was smart
But you made me look so naive
The way you sold me for parts
As you sunk your teeth into me, oh
Bloodsucker, fame fucker
Bleedin' me dry like a goddamn vampire
(Ah)
You said it was true love, but wouldn't that be hard?
You can't love anyone 'cause that would mean you had a heart
I tried to help you out, now I know that I can't
'Cause how you think's the kind of thing I'll never understand
I've made some real big mistakes
But you make the worst one look fine
I should've known it was strange
You only come out at night
I used to think I was smart
But you made me look so naive
The way you sold me for parts
As you sunk your teeth into me, oh
Bloodsucker, fame fucker
Bleedin' me dry like a goddamn vampire
EOF
}

output1() {
    cat <<EOF
1	age
1	ah
1	anyone
1	asking
1	be
1	better
1	built
1	care about
1	castle
1	close
1	convincing
1	cool
1	diamonds
1	doing
1	em
1	ever
1	every
1	eyes
1	figure
1	flinching
1	forbidden
1	fucked
1	girl
1	girls
1	give
1	got
1	gotta
1	guy
1	had
1	hard
1	heart
1	help
1	her
1	how's
1	i'll
1	kind
1	knows
1	laugh
1	little
1	loved
1	mean
1	mesmerizing
1	months
1	my
1	news
1	not
1	off
1	paradise
1	paralyzing
1	parties
1	people you pretend
1	said
1	satisfaction
1	see
1	six
1	sometimes
1	stupidity
1	talked
1	them
1	thing
1	think's
1	thrill
1	told
1	too
1	torture
1	tried
1	true
1	truly
1	understand
1	up
1	wanted
1	went
1	were
1	when
1	will
1	without
1	would
1	wouldn't
2	bad
2	called
2	crazy
2	god
2	hate
2	just
2	know
2	love
2	never
2	now
2	of
2	what
2	you're
3	big
3	bleedin
3	bloodsucker
3	can't
3	come
3	dry
3	fame
3	fine
3	fucker
3	goddamn
3	i've
3	into
3	known
3	like
3	make
3	mistakes
3	naive
3	night
3	one
3	only
3	parts
3	real
3	should've
3	smart
3	strange
3	sunk
3	teeth
3	that
3	think
3	used
3	vampire
3	worst
4	and
4	as
4	cause
4	for
4	lie
4	oh
4	so
4	sold
4	some
4	way
4	your
5	a
5	at
5	do
5	out
6	it
6	made
7	but
7	how
7	look
7	to
7	was
13	the
14	me
19	i
33	you
EOF
}

# Setup

mkdir $WORKSPACE

trap "cleanup" EXIT
trap "cleanup 1" INT TERM

# Tests

echo "Testing $PROGRAM ..."

printf " %-40s ... " "The Swan, 0.50, FNV (output)"
diff -y <(input0 | ./$EXECUTABLE | LC_ALL=C sort -n) <(output0) &> $WORKSPACE/test
if [ $? -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "The Swan, 0.50, FNV (valgrind)"
input0 | valgrind --leak-check=full ./$EXECUTABLE &> $WORKSPACE/test
if [ $? -ne 0 ] || [ $(awk '/ERROR SUMMARY:/ {print $4}' $WORKSPACE/test) -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "The Swan, 0.75, FNV (output)"
FLAGS="-a 0.75"
diff -y <(input0 | ./$EXECUTABLE $FLAGS | LC_ALL=C sort -n) <(output0) &> $WORKSPACE/test
if [ $? -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "The Swan, 0.75, FNV (valgrind)"
input0 | valgrind --leak-check=full ./$EXECUTABLE $FLAGS &> $WORKSPACE/test
if [ $? -ne 0 ] || [ $(awk '/ERROR SUMMARY:/ {print $4}' $WORKSPACE/test) -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "Vampire, 0.50, FNV (output)"
diff -y <(input1 | ./$EXECUTABLE | LC_ALL=C sort -n) <(output1) &> $WORKSPACE/test
if [ $? -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "Vampire, 0.50, FNV (valgrind)"
input1 | valgrind --leak-check=full ./$EXECUTABLE &> $WORKSPACE/test
if [ $? -ne 0 ] || [ $(awk '/ERROR SUMMARY:/ {print $4}' $WORKSPACE/test) -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "Vampire, 0.75, FNV (output)"
FLAGS="-a 0.75"
diff -y <(input1 | ./$EXECUTABLE $FLAGS | LC_ALL=C sort -n) <(output1) &> $WORKSPACE/test
if [ $? -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

printf " %-40s ... " "Vampire, 0.75, FNV (valgrind)"
input1 | valgrind --leak-check=full ./$EXECUTABLE $FLAGS &> $WORKSPACE/test
if [ $? -ne 0 ] || [ $(awk '/ERROR SUMMARY:/ {print $4}' $WORKSPACE/test) -ne 0 ]; then
    error "Failure"
else
    echo "Success"
fi

TESTS=$(($(grep -c Success $0) - 1))

echo
echo "   Score $(echo "scale=4; ($TESTS - $FAILURES) / $TESTS.0 * $POINTS.0" | bc | awk '{ printf "%0.2f\n", $1 }' ) / $POINTS.00"
printf "  Status "
if [ $FAILURES -eq 0 ]; then
    echo "Success"
else
    echo "Failure"
fi
echo
