/* table.h: Table Structure */

#pragma once

#include "hash.h"
#include "pair.h"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

/* Constants */

#define DEFAULT_CAPACITY    (1<<3)

/* Structures */

typedef struct {
    Pair          **buckets;
    size_t          capacity;
    size_t          size;
    double          alpha;
    HashFunction    hash;
} Table;

/* Functions */

Table *	    table_create(int capacity, double alpha, HashFunction hash);
void        table_delete(Table *t);

int     table_locate(Table *t, const char *key);

void        table_insert(Table *t, const char *key, long value);
long     table_lookup(Table *t, const char *key);
void	    table_format(Table *t, FILE *stream);
void        table_resize(Table *t, int capacity);

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
