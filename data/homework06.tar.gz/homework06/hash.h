/* hash.h: Hash Functions */

#pragma once

#include <stdint.h>
#include <stdlib.h>

/* Type Definitions */

typedef long (*HashFunction)(const void *data, int n);

/* Functions */

// long    djb_hash(const void *data, int n);
long    fnv_hash(const void *data, int n);

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
