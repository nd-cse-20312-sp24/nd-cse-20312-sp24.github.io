/* pair.h: Key/Value Pair Structure */

#pragma once

#include <stdint.h>
#include <stdio.h>

/* Structures */

typedef struct {
    char   *key;
    long value;
} Pair;

/* Functions */

Pair *      pair_create(const char *key, long value);
void        pair_delete(Pair *p);
void        pair_format(Pair *p, FILE *stream);

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
