/* table.c: Table Structure */

#include "table.h"

#include <string.h>

/**
 * Allocate and initialize new Table structure.
 *
 * @param   capacity        Number of buckets in the hash table.
 * @param   alpha           Maximum load factor for hash table.
 * @param   hash            Hash function to use for hash table.
 * @return  New Table structure (must be deleted later).
 **/
Table *	    table_create(int capacity, double alpha, HashFunction hash) {
    //TODO
    return NULL;
}

/**
 * Release internal pairs and buckets and then the Table structure itself.
 *
 * @param   t               Pointer to the Table structure.
 **/
void        table_delete(Table *t) {
    //TODO
}

/**
 * Locate bucket index for given key using linear probing.
 *
 *  1. If key is already in table, it returns the index of Pair with the
 *  corresponding key.
 *
 *  2. If key is not in table, it returns the index where a new Pair should be
 *  inserted.
 *
 *  3. If key is not in table and it is not possible to insert a new Pair, it
 *  returns -1.
 *
 * @param   t               Pointer to the Table structure.
 * @param   key             Key string to locate.
 * @return  Index where Pair with key can be found or inserted (-1 if not possible).
 **/
int     table_locate(Table *t, const char *key) {
    //TODO
    return -1;
}

/**
 * Add key/value Pair to Table structure.
 *
 * @param   t               Pointer to the Table structure.
 * @param   key             String key of Pair.
 * @param   value           Integer value of Pair.
 **/
void        table_insert(Table *t, const char *key, long value) {
    //TODO
}

/**
 * Lookup key in Table structure.
 *
 * @param   t               Pointer to the Table structure.
 * @param   key             String Key of Pair.
 * @return  Value associated with key if it is in table, otherwise -1.
 **/
long     table_lookup(Table *t, const char *key) {
    //TODO
}

/**
 * Format all the pairs in the Table structure.
 *
 * @param   t               Pointer to the Table structure.
 * @param   stream          File stream to write to.
 **/
void	    table_format(Table *t, FILE *stream) {
    //TODO
}

/**
 * Resize the current Table structure with the new capacity.
 *
 * @param   t               Pointer to the Table structure.
 * @param   capacity        New capacity of Table structure.
 **/
void        table_resize(Table *t, int capacity) {
    //TODO
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */