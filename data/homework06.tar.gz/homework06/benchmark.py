#!/usr/bin/env python3

import collections
import concurrent.futures
import os
import subprocess
import sys
import time

# Constants

HASH_FUNCTIONS = (
    ('FNV', '-f'),
    ('DJB', '-d'),
)
ALPHAS = [n/100 for n in range(50, 100, 5)]
RUNS   = 10

# Functions

def run_once(args):
    start_time = time.time()
    command    = ['bin/freq'] + list(args[:-1])
    subprocess.run(command,
        stdin  = open(args[-1]),
        stdout = subprocess.DEVNULL,
    )
    return time.time() - start_time

# Main Execution

def main():
    if len(sys.argv) != 2:
        print(f'Usage: {sys.argv[0]} path')
        sys.exit(1)

    results = collections.defaultdict(dict)

    for hash_name, hash_flag in HASH_FUNCTIONS:
        for alpha in ALPHAS:
            with concurrent.futures.ProcessPoolExecutor() as executor:
                args    = [('-a', str(alpha), hash_flag, sys.argv[1]) for _ in range(RUNS)]
                times   = list(executor.map(run_once, args))
                average = sum(times) / len(times)

            results[hash_name][alpha] = average


    print('ALPHA\tFNV\tDJB')
    for alpha in ALPHAS:
        print(f'{alpha:>5.2f}\t{results["FNV"][alpha]:5.3f}s\t{results["DJB"][alpha]:5.3f}s')

if __name__ == '__main__':
    main()
