#include "set.h"

Set* set_create() {
    // TODO:
}

void set_delete(Set *set) {
    // TODO:
}

bool set_contains(Set *set, int value) {
    // TODO:
}

void set_add(Set *set, int value) {
    // TODO:
}

void set_remove(Set *set, int value) {
    // TODO:
}