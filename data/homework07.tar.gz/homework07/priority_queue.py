#!/usr/bin/env python3

# Class

class PriorityQueue:
    ''' Priority Queue

    Stores values in ascending order.
    '''

    def __init__(self, data=None):
        ''' Construct PriorityQueue with initial data.

        >>> p = PriorityQueue()
        >>> p.data
        []

        >>> p = PriorityQueue([5, 7, 4])
        >>> p.data
        [4, 5, 7]
        '''
        # TODO
        if (data):
            self.data = sorted(data)
        else:
            self.data = []

    def push(self, value):
        ''' Add value to PriorityQueue.

        >>> p = PriorityQueue()
        >>> for i in (5, 7, 4): p.push(i)
        >>> p.data
        [4, 5, 7]
        '''
        # TODO
        index = 0
        while index < len(self.data) and self.data[index] < value:
            index += 1
        self.data.insert(index, value)

    def pop(self):
        ''' Remove largest value from PriorityQueue.

        >>> p = PriorityQueue([5, 7, 4])
        >>> [p.pop(), p.pop(), p.pop()]
        [7, 5, 4]
        '''
        # TODO
        return self.data.pop()

    @property
    def front(self):
        ''' Return largest value from PriorityQueue.

        >>> p = PriorityQueue([5, 7, 4])
        >>> p.front
        7
        '''
        # TODO
        return self.data[-1]

    @property
    def empty(self):
        ''' Return whether or not the PriorityQueue has any values.

        >>> PriorityQueue().empty
        True

        >>> PriorityQueue([5, 7, 4]).empty
        False
        '''
        # TODO
        return len(self.data) == 0

    def __len__(self):
        ''' Return number of values in PriorityQueue.

        >>> len(PriorityQueue())
        0

        >>> len(PriorityQueue([5, 7, 4]))
        3
        '''
        # TODO
        return len(self.data)
