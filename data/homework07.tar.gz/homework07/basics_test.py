#!/usr/bin/env python3

import unittest

class BasicsTest(unittest.TestCase):
    Total  = 2
    Points = 0

    @classmethod
    def setupClass(cls):
        cls.Points = 0

    @classmethod
    def tearDownClass(cls):
        print()
        print(f'   Score {cls.Points:.2f} / {cls.Total:.2f}')
        print(f'  Status {"Success" if cls.Points >= cls.Total else "Failure"}')
    
    def test_00(self):
        # Define a list with items (in order): 7, 'a', 3.14, 'hello'
        mixed_list = None

        # Use [] notation to get the value of the first item in the list
        mixed_list_first = None

        # Use [] notation with a negative index to get the value of the last item in the list
        mixed_list_last = None

        self.assertEqual(mixed_list_first, 7)
        self.assertEqual(mixed_list_last, 'hello')
        BasicsTest.Points += 0.5

    def test_01(self):
        a = [2, 1, 4, 3]
        # Use a function to get a new list with the items in a sorted,
        # without changing the order of items in a
        s = None

        self.assertEqual(s, [1, 2, 3, 4])
        self.assertEqual(a, [2, 1, 4, 3])

        # Use a method to sort the items of a in-place (e.g modify a)
        pass

        self.assertEqual(a, [1, 2, 3, 4])

        # Use a method to remove the first item in a and return its value
        p = None

        self.assertEqual(a, [2, 3, 4])
        self.assertEqual(p, 1)
        BasicsTest.Points += 0.5

    def test_02(self):
        s = '1 2 3'
        # Split the string s into a list of substrings delimited by whitespace
        slist = None

        self.assertEqual(slist, ['1', '2', '3'])

        # Use list comprehension to convert the list of strings in slist to a list of integers
        ilist = None

        self.assertEqual(ilist, [1, 2, 3])

        # Use the join method to convert ilist to a string of comma-separated integers
        cs = None

        self.assertEqual(cs, '1,2,3')
        BasicsTest.Points += 0.5

    def test_03(self):
        # Use {} notation to create a dictionary with indices 
        # 'apple', 'banana', 'durian' and corresponding values 7, 8, 10
        d = None

        self.assertEqual(type(d), dict)
        self.assertEqual(set(d.keys()), {'apple', 'banana', 'durian'})
        self.assertEqual(set(d.values()), {7, 8, 10})

        # Add another entry to the dictionary with index 'cantaloupe' and value 9
        pass

        self.assertTrue(('cantaloupe', 9) in d.items())

        # Use {} notation to create a set with values 1, 2, 3
        s = None

        self.assertEqual(type(s), set)
        self.assertTrue(s.issubset(range(1,4)))
        self.assertEqual(len(s), 3)
        BasicsTest.Points += 0.5

if __name__ == '__main__':
    unittest.main()
