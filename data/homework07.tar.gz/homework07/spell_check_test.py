#!/usr/bin/env python3

import doctest
import io
import unittest
import unittest.mock

import spell_check

# Unit Tests

class SpellCheckTest(unittest.TestCase):
    Poem  = ('''
’Twas brillig, and the slithy toves
Did gyre and gimble in the wabe:
All mimsy were the borogoves,
And the mome raths outgrabe.
''')
    Total  = 3
    Points = 0

    @classmethod
    def setupClass(cls):
        cls.Points = 0

    @classmethod
    def tearDownClass(cls):
        print()
        print(f'   Score {cls.Points:.2f} / {cls.Total:.2f}')
        print(f'  Status {"Success" if cls.Points >= cls.Total else "Failure"}')

    def test_00_word_list(self):
        words = spell_check.WordsList()
        self.assertTrue(isinstance(words.data, list))
        self.assertTrue(isinstance(words.data, list))
        self.assertTrue(len(words.data) >= 100000)
        self.assertTrue('the' in words)
        self.assertFalse('thurr' in words)
        self.assertTrue('zoologist' in words)
        self.assertFalse('Daedalae' in words)
        SpellCheckTest.Points += 0.5

    def test_01_word_set(self):
        words = spell_check.WordsSet()
        self.assertTrue(isinstance(words.data, set))
        self.assertTrue(len(words.data) >= 100000)
        self.assertTrue('the' in words)
        self.assertFalse('thurr' in words)
        self.assertTrue('zoologist' in words)
        self.assertFalse('Daedalae' in words)
        SpellCheckTest.Points += 0.5

    def test_02_main_default(self):
        with unittest.mock.patch('sys.stdout', new=io.StringIO()) as output:
            spell_check.main('', io.StringIO(self.Poem))
            lines = output.getvalue().splitlines()

        self.assertTrue(len(lines) >= 9)
        self.assertEqual(lines[ 0], '’Twas')
        self.assertEqual(lines[-1], 'outgrabe.')
        SpellCheckTest.Points += 1

    def test_03_main_list(self):
        with unittest.mock.patch('sys.stdout', new=io.StringIO()) as output:
            spell_check.main('-l', io.StringIO(self.Poem))
            lines = output.getvalue().splitlines()

        self.assertTrue(len(lines) >= 9)
        self.assertEqual(lines[ 0], '’Twas')
        self.assertEqual(lines[-1], 'outgrabe.')
        SpellCheckTest.Points += 0.5

    def test_04_main_set(self):
        with unittest.mock.patch('sys.stdout', new=io.StringIO()) as output:
            spell_check.main('-s', io.StringIO(self.Poem))
            lines = output.getvalue().splitlines()

        self.assertTrue(len(lines) >= 9)
        self.assertEqual(lines[ 0], '’Twas')
        self.assertEqual(lines[-1], 'outgrabe.')
        SpellCheckTest.Points += 0.5

# Main Execution

if __name__ == '__main__':
    unittest.main()
