#!/usr/bin/env python3

import doctest
import unittest

import priority_queue

# Unit Tests

class PriorityQueueTest(unittest.TestCase):
    Data   = [9, 2, 8, 6, 7]
    Total  = 3
    Points = 0

    @classmethod
    def setupClass(cls):
        cls.Points = 0

    @classmethod
    def tearDownClass(cls):
        print()
        print(f'   Score {cls.Points:.2f} / {cls.Total:.2f}')
        print(f'  Status {"Success" if cls.Points >= cls.Total else "Failure"}')
    
    def test_00_constructor(self):
        p = priority_queue.PriorityQueue()
        self.assertEqual(p.data, [])

        p = priority_queue.PriorityQueue([5, 7, 4])
        self.assertEqual(p.data, [4, 5, 7])
        
        PriorityQueueTest.Points += 0.5
    
    def test_01_push(self):
        p = priority_queue.PriorityQueue()
        self.assertEqual(p.data, [])

        p.push(5)
        self.assertEqual(p.data, [5])
        p.push(4)
        self.assertEqual(p.data, [4, 5])
        p.push(7)
        self.assertEqual(p.data, [4, 5, 7])

        PriorityQueueTest.Points += 0.5
    
    def test_02_pop(self):
        p = priority_queue.PriorityQueue([5, 7, 4])
        self.assertEqual(p.data, [4, 5, 7])

        self.assertEqual(p.pop(), 7)
        self.assertEqual(p.data, [4, 5])
        self.assertEqual(p.pop(), 5)
        self.assertEqual(p.pop(), 4)
        self.assertEqual(p.data, [])

        PriorityQueueTest.Points += 0.5
    
    def test_03_front(self):
        p = priority_queue.PriorityQueue([5, 7, 4])
        self.assertEqual(p.data, [4, 5, 7])

        self.assertEqual(p.front, 7)

        PriorityQueueTest.Points += 0.5
    
    def test_04_empty(self):
        p = priority_queue.PriorityQueue()
        self.assertTrue(p.empty)

        p.push(4)
        self.assertFalse(p.empty)

        p.pop()
        self.assertTrue(p.empty)

        PriorityQueueTest.Points += 0.5

    def test_05_len(self):
        p = priority_queue.PriorityQueue()
        self.assertEqual(len(p), 0)

        p = priority_queue.PriorityQueue([5, 7, 4])
        self.assertEqual(len(p), 3)

        p.pop()
        self.assertEqual(len(p), 2)

        PriorityQueueTest.Points += 0.5

# Main Execution

if __name__ == '__main__':
    unittest.main()
