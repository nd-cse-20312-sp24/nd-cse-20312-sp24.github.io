#!/usr/bin/env python3

import doctest
import io
import unittest
import unittest.mock

import cups

# Unit Tests

class CupsTest(unittest.TestCase):
    Total  = 2
    Points = 0

    @classmethod
    def setupClass(cls):
        cls.Points = 0

    @classmethod
    def tearDownClass(cls):
        print()
        print(f'   Score {cls.Points:.2f} / {cls.Total:.2f}')
        print(f'  Status {"Success" if cls.Points >= cls.Total else "Failure"}')
    
    def test_00_fill_cups(self):
        self.assertEqual(cups.fill_cups([1, 4, 2]), 4)
        self.assertEqual(cups.fill_cups([5, 4, 4]), 7)
        self.assertEqual(cups.fill_cups([5, 0, 0]), 5)

        CupsTest.Points += 1.0
    
    def test_01_main(self):
        indata = io.StringIO('1 4 2\n5 4 4\n5 0 0\n')
        with unittest.mock.patch('sys.stdout', new=io.StringIO()) as output:
            cups.main(indata)
            outstrings = output.getvalue().splitlines()
            outvalues = [int(s) for s in outstrings]
            self.assertEqual(outvalues, [4, 7, 5])
        CupsTest.Points += 1.0

# Main Execution

if __name__ == '__main__':
    unittest.main()
