#!/usr/bin/env python3

# import collections
import sys

# Constants

WORDS_PATH = '/usr/share/dict/words'

# Classes

class WordsDatabase:
    ''' Words DataBase.

    Supports the "in" operation.
    '''

    def __contains__(self, target):
        ''' Returns whether or not target is in the database. '''
        # We'll do this one for you
        return target in self.data

class WordsList(WordsDatabase):
    ''' Words Database that uses a list internally. '''

    def __init__(self, path=WORDS_PATH):
        ''' Construct Words Database by loading all words in path into internal
        list.

        >>> words = WordsList()
        >>> len(words.data) >= 100000
        True

        >>> 'the' in words
        True

        >>> 'thurr' in words
        False
        '''
        # TODO
        

class WordsSet(WordsDatabase):
    ''' Words Database that uses a set internally. '''

    def __init__(self, path=WORDS_PATH):
        ''' Construct Words Database by loading all words in path into internal
        set.

        >>> words = WordsSet()
        >>> len(words.data) >= 100000
        True

        >>> 'the' in words
        True

        >>> 'thurr' in words
        False
        '''
        # TODO
        

# Constants

WORDS_DATABASES = {
    '-l': WordsList,
    '-s': WordsSet,
}

# Main Execution

def main(arguments=sys.argv[1:], stream=sys.stdin):
    ''' Perform a spell check on each word in the stream:

    1. Load appropriate Words Database.
    2. Read each line from stream.
    3. Check each word from each line.
    4. Print any words that are not in the Words Database.

    >>> main(['-l'], io.StringIO('the thurr\\nshe shurr\\n'))
    thurr
    shurr

    >>> main(['-s'], io.StringIO('the thurr\\nshe shurr\\n'))
    thurr
    shurr
    '''
    # TODO
    

if __name__ == '__main__':
    main()
