#!/usr/bin/env python3

from typing import Tuple
import sys

# Functions

def is_balanced(array: list[int], index: int=0) -> Tuple[bool, int]:
    ''' Determine whether or not a binary tree is balanced.

    A binary tree is balanced if:

    1. Left and right sub-trees are balanced.
    2. Difference between heights of left and right sub-trees is no more than 1.

    >>> is_balanced([5, 3, 6])
    (True, 2)

    >>> is_balanced([5, 3, 0, 4])
    (False, 3)
    '''
    pass


# Main Execution

def main(stream=sys.stdin) -> None:
    ''' For each line with a tree given in BFS format, output whether or not it
    is balanced.

    >>> import io
    >>> main(io.StringIO('5 3 6\\n5 3 0 4\\n'))
    Balanced
    Not Balanced
    '''
    pass
        
if __name__ == '__main__':
    main()
