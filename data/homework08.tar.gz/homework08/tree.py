#!/usr/bin/env python3

from dataclasses import dataclass
from typing      import Iterator, Optional

# Classes

@dataclass
class Node:
    value:  int
    left:   Optional['Node'] = None
    right:  Optional['Node'] = None

# Functions

def tree_read(array: list[int], index: int=0) -> Optional[Node]:
    ''' Return a node-based tree from the given array of values in BFS format.

    >>> tree_read([1, 2, 3])
    Node(value=1, left=Node(value=2, left=None, right=None), right=Node(value=3, left=None, right=None))
    '''
    pass

def tree_values(root: Optional[Node]) -> Iterator[int]:
    ''' Generate all the values in the tree recursively in-order.

    >>> list(tree_values(Node(value=1, left=Node(value=2, left=None, right=None), right=Node(value=3, left=None, right=None))))
    [2, 1, 3]
    '''
    pass

def tree_array(root: Optional[Node]) -> list[int]:
    ''' Convert the Node-based tree into the equivalent array in BFS
    (level-by-level) format.

    >>> tree_array(Node(value=1, left=Node(value=2, left=None, right=None), right=Node(value=3, left=None, right=None)))
    [1, 2, 3]
    '''
    pass

