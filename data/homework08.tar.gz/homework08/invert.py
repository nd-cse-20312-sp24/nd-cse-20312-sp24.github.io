#!/usr/bin/env python3

import sys

from typing import Optional
from tree   import Node, tree_read, tree_array

# Functions

def tree_invert(node: Optional[Node]) -> Optional[Node]:
    ''' Invert tree in-place using divide and conquere.

    >>> tree_array(tree_invert(tree_read([1, 2, 3])))
    [1, 3, 2]
    '''
    pass



# Main Execution

def main(stream=sys.stdin):
    ''' For each line, read in the tree in BFS format, print it, invert it, and
    then print it again.

    >>> import io
    >>> main(io.StringIO('1 2 3\\n'))
    1, 2, 3
    1, 3, 2
    '''
    pass

if __name__ == '__main__':
    main()
